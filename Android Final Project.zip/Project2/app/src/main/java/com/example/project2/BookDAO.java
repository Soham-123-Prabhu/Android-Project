package com.example.project2;


import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface BookDAO {

    @Insert
    void AddBook(Book b);

    @Query("SELECT COUNT(*) FROM bookBank")
    int bcount();

    @Query("SELECT * FROM bookBank where (title= :title)")
    Book findBytitle(String title);

    @Query("SELECT * FROM bookBank where (genre= :genre)")
    List<Book> findBygenre(String genre);

    @Query("SELECT * FROM bookBank")
    List<Book> getAllBooks();

//    @Query("SELECT resNum FROM bookBank where title= :title");
//     int showByrid(String title);
    @Query("SELECT resNum FROM bookBank where (title= :title)")
    int findResNum(String title);

    @Query("DELETE FROM bookBank where title= :title")
    void RemoveByTitle(String title);

    @Delete
    void delete(Book book);
}
