package com.example.project2;

import static android.widget.Toast.LENGTH_LONG;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.project2.databinding.ActivityMainBinding;

public class ManageSys extends AppCompatActivity {

    private ActivityMainBinding binding;
    private String libName;
    private String libPass;
    private int loginCount;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_sys);

        EditText tv1=findViewById(R.id.Lib_username);
        EditText tv2=findViewById(R.id.Lib_password);
        Button myb1=findViewById(R.id.LibSubmitButton);

        myb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String username=tv1.getText().toString();
                String password=tv2.getText().toString();
                if(username.equals("!admin2") && password.equals("!admin2")){
                    Intent i=new Intent(ManageSys.this,ManageSysLog2.class);
                    startActivity(i);
                }
                else{

                        String text="Wrong credentials";
                        Toast.makeText(ManageSys.this,text,Toast.LENGTH_LONG).show();
                        loginCount++;
                        if(loginCount==2){
                            Intent i=new Intent(ManageSys.this,MainActivity.class);
                            Bundle info=new Bundle();
                            i.putExtras(info);
                            startActivity(i);
                        }




                }
            }
        });


    }
}