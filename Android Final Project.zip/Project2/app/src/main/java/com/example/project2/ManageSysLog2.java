package com.example.project2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.project2.databinding.ActivityMainBinding;
import com.example.project2.databinding.ActivityManageSysLog2Binding;

public class ManageSysLog2 extends AppCompatActivity {
    private ActivityManageSysLog2Binding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityManageSysLog2Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Button y = binding.yesButton;
        Button n = binding.noButton;
        Button tra=binding.transYes;

        y.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(ManageSysLog2.this, AddBook.class);
                startActivity(i);
            }
        });

        n.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(ManageSysLog2.this, ManageSys.class);
                startActivity(i);
            }
        });

        tra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(ManageSysLog2.this, TransactionActivity.class);
                startActivity(i);
            }
        });





    }
}