package com.example.project2;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface TransactionDAO {

    @Insert
    void addTransaction(Transaction t);

  //  @Query("SELECT COUNT(*) FROM transactionBank")
   // int tcount;

    @Query("Select type from transactionBank where title= :title")
    String gettype(String title);

    @Query("SELECT * FROM transactionBank")
    List<Transaction> getAlltransactions();
}
