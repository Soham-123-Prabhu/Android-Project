package com.example.project2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class TransactionActivity extends AppCompatActivity {

    private LibraryDatabase db;
    List<Transaction> tranBank;
   // private Transaction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaction);

        db = LibraryDatabase.getInstance(TransactionActivity.this);
       tranBank =db.transaction().getAlltransactions();

        TextView tv=findViewById(R.id.alltran);

        if(tranBank!=null){
            tv.setText(tranBank.toString());
        }
        else{
            Log.d("trial", String.valueOf(tranBank));
        }




    }
}