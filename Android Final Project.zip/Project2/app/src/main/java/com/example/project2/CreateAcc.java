package com.example.project2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.project2.databinding.ActivityMainBinding;

import java.util.List;

public class CreateAcc extends AppCompatActivity {
    private ActivityMainBinding binding;
    private LibraryDatabase db;
    private List<User> userBank;
    private User user;
    int loginCount = 0;
    private List<Transaction> transactionBank;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        db = LibraryDatabase.getInstance(CreateAcc.this);
        db.populateInitialData();
        userBank = db.user().getAll();
        transactionBank=db.transaction().getAlltransactions();


        setContentView(R.layout.activity_create_acc2);

        Button CAw = findViewById(R.id.LogInButton);
        EditText un = findViewById(R.id.username);
        EditText pass = findViewById(R.id.password);


        CAw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String uname = un.getText().toString();
                String pw = pass.getText().toString();
                User userA = new User(uname, pw);

                LibraryDatabase libDB = LibraryDatabase.getInstance(getApplicationContext());
                UserDAO uDAO = libDB.user();
                userBank = db.user().getAll();
                user = db.user().findByusername(uname);
                if (uname.isEmpty() && pw.isEmpty()) {
                    Toast.makeText(CreateAcc.this, "Please enter all values", Toast.LENGTH_SHORT).show();
                    loginCount++;
                    if (loginCount>=2) {
                        Intent i = new Intent(CreateAcc.this, MainActivity.class);
                        Bundle info = new Bundle();
                        i.putExtras(info);
                        startActivity(i);
                    }
                }


//                else if(userBank.contains(userA)){
                else if (user != null) {
                    loginCount++;
                    if (loginCount>=2) {
                        Intent i = new Intent(CreateAcc.this, MainActivity.class);
                        Bundle info = new Bundle();
                        i.putExtras(info);
                        startActivity(i);
                    }
                    Toast.makeText(CreateAcc.this, "Customer already exists", Toast.LENGTH_SHORT).show();
                }
                else {

                    db.user().addUser(userA);
                    db.transaction().addTransaction(new Transaction("Create account",uname,""));
                    Intent i = new Intent(CreateAcc.this, MainActivity.class);
                    Bundle info = new Bundle();
                    i.putExtras(info);
                    startActivity(i);
                    Toast.makeText(CreateAcc.this, "Created", Toast.LENGTH_SHORT).show();

                }

//                if(user.getUsername().equals(uDAO.findByusername)){
//                    Toast.makeText(CreateAcc.this, "Logged In", Toast.LENGTH_SHORT).show();
//                    Intent i=new Intent(CreateAcc.this,MainActivity.class);
//                    startActivity(i);
//                }

         //       debug.setText(db.book().getAllBooks().toString());

            }
        });
    }
}