package com.example.project2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class Memoir extends AppCompatActivity {
    private LibraryDatabase db;
    private List<Book> bookBank;
    private Book memoirBook;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_memoir);

        db=LibraryDatabase.getInstance(Memoir.this);
        db.populateInitialData();
        bookBank=db.book().getAllBooks();

        EditText mbt=findViewById(R.id.btitle);
        EditText mun=findViewById(R.id.name);
        EditText mp=findViewById(R.id.pass);
        Button mph=findViewById(R.id.hold);

        LibraryDatabase libDB = LibraryDatabase.getInstance(getApplicationContext());
        UserDAO uDAO = libDB.user();
        BookDAO bDAO=libDB.book();


        mph.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String btitle=mbt.getText().toString();
                bookBank=db.book().getAllBooks();
                memoirBook=db.book().findBytitle(btitle);


                String musn=mun.getText().toString();
                String mpw=mph.getText().toString();

                if(btitle.isEmpty() && musn.isEmpty() &&mpw.isEmpty()){
                    Toast.makeText(Memoir.this, "Please enter all values", Toast.LENGTH_SHORT).show();
                    Log.d("trial",btitle);
                }
                else if(memoirBook != null){
                    String text1="Hold placed on \n Book: "+btitle+"by \n Customer Username"+ musn;
                    Toast.makeText(Memoir.this,text1,Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(Memoir.this, MainActivity.class);
                    db.book().delete(memoirBook);
                    db.transaction().addTransaction(new Transaction("Hold placed on",musn,btitle));
//                    db.book();

                }
                else if(memoirBook== null){
                    String text="Book not found";
                    Toast.makeText(Memoir.this,text,Toast.LENGTH_SHORT).show();
                }
            }
        });


    }
}