package com.example.project2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class PlaceHold extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_hold);

        Button CS=findViewById(R.id.CompSci);
        Button Fic=findViewById(R.id.Fiction);
        Button Mem=findViewById(R.id.Memoir);

        CS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String CS="Computer Science";
                Intent i=new Intent(PlaceHold.this,CompSci.class);
                Bundle info=new Bundle();
                info.putString("Genre",CS);
                i.putExtras(info);
                startActivity(i);
                i.putExtras(info);
            }
        });
        Fic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String FI="Fiction";
                Intent i=new Intent(PlaceHold.this,Fiction.class);
                startActivity(i);
            }
        });

        Mem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String memoir="Memoir";
                Intent i=new Intent(PlaceHold.this,Memoir.class);
                startActivity(i);
            }
        });
    }


}