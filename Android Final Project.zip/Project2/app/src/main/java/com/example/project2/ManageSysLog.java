package com.example.project2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.project2.databinding.ActivityMainBinding;
import com.example.project2.databinding.ActivityManageSysLog2Binding;
import com.example.project2.databinding.ActivityManageSysLogBinding;

public class ManageSysLog extends AppCompatActivity {
private ActivityManageSysLogBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityManageSysLogBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());



        Button y=findViewById(R.id.yes_button1);
        Button n=findViewById(R.id.no_button1);


        y.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(ManageSysLog.this, AddBook.class);
                startActivity(i);
            }
        });

        n.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(ManageSysLog.this, ManageSys.class);
                startActivity(i);
            }
        });



    }
}