package com.example.project2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class Fiction extends AppCompatActivity {

    private LibraryDatabase db;
    private List<Book> bookBank;
    private Book fictionBook;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fiction);

        db=LibraryDatabase.getInstance(Fiction.this);
        db.populateInitialData();
        bookBank=db.book().getAllBooks();

        EditText fbt=findViewById(R.id.btitle);
        EditText fun=findViewById(R.id.name);
        EditText fp=findViewById(R.id.pass);
        Button fph=findViewById(R.id.hold);

        LibraryDatabase libDB = LibraryDatabase.getInstance(getApplicationContext());
        UserDAO uDAO = libDB.user();
        BookDAO bDAO=libDB.book();

        fph.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String btitle=fbt.getText().toString();
                bookBank=db.book().getAllBooks();
                fictionBook=db.book().findBytitle(btitle);

                String fusn=fun.getText().toString();
                String fpw=fph.getText().toString();

                if(btitle.isEmpty() && fusn.isEmpty() &&fpw.isEmpty()){
                    Toast.makeText(Fiction.this, "Please enter all values", Toast.LENGTH_SHORT).show();
                    Log.d("trial",btitle);
                }
                else if(fictionBook != null){
                    String text1="Hold placed on \n Book: "+btitle+"by \n Customer Username"+ fusn;
                    Toast.makeText(Fiction.this,text1,Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(Fiction.this, MainActivity.class);
                    db.book().delete(fictionBook);
                    db.transaction().addTransaction(new Transaction("Hold placed on",fusn,btitle));
//                    db.book();

                }
                else if(fictionBook== null){
                    String text="Book not found";
                    Toast.makeText(Fiction.this,text,Toast.LENGTH_SHORT).show();
                }
            }
        });




    }
}