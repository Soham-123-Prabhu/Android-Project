package com.example.project2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.project2.databinding.ActivityAddBookBinding;
import com.example.project2.databinding.ActivityMainBinding;

import java.util.List;

public class AddBook extends AppCompatActivity {

    private ActivityAddBookBinding binding;
    private LibraryDatabase db;
    private List<Book> bookBank;
    private Book book;
    int loginCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAddBookBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        db = LibraryDatabase.getInstance(AddBook.this);
        db.populateInitialData();
        bookBank=db.book().getAllBooks();

        EditText tl=findViewById(R.id.booktitle);
        EditText auth=findViewById(R.id.author);
        EditText genre=findViewById(R.id.genre);
        EditText rID=findViewById(R.id.resid);
        Button addb=binding.bookSubmit;
        addb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String title=tl.getText().toString();
                String author=auth.getText().toString();
                String gen=genre.getText().toString();
                Integer rid=Integer.parseInt(rID.getText().toString());

                LibraryDatabase libDB = LibraryDatabase.getInstance(getApplicationContext());
                BookDAO bDAO = libDB.book();

                if(title.isEmpty() || author.isEmpty() || gen.isEmpty() ){  //need to add if ID is empty
                    Toast.makeText(AddBook.this, "Please enter all values", Toast.LENGTH_SHORT).show();
                    loginCount++;
                    if(loginCount==2){
                        Intent i = new Intent(AddBook.this, ManageSysLog.class);
                        startActivity(i);
                    }
                }
                else{
                    book = new Book(title, author, gen, rid);
                    db.book().AddBook(book);
                    Toast.makeText(AddBook.this, "Book has been entered into the database", Toast.LENGTH_SHORT).show();


                }
            }
        });
    }
}