package com.example.project2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

public class CompSci extends AppCompatActivity {

    private LibraryDatabase db;
   // private List<Book> bookBank;
    private List<User> userBank;
    private User user;
    private Book book;
    private Book selectedBook;
    private Book csB;
    private ListView triviaListView;
    private List<Book> compSciList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comp_sci);

        db = LibraryDatabase.getInstance(CompSci.this);
        db.populateInitialData();
        compSciList=db.book().getAllBooks();
        userBank=db.user().getAll();

        EditText bt=findViewById(R.id.btitle);
        EditText un=findViewById(R.id.name);
        EditText p=findViewById(R.id.pass);
        Button ph=findViewById(R.id.hold);


        LibraryDatabase libDB = LibraryDatabase.getInstance(getApplicationContext());
        UserDAO uDAO = libDB.user();
        BookDAO bDAO=libDB.book();


        ph.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String btitle=bt.getText().toString();

                if (btitle.equals("Strengthening Deep Neural Networks")) {
                    Log.d("trial", "strings are equal");
                }

                Log.d("trial", btitle);
                compSciList =db.book().getAllBooks();
                selectedBook=db.book().findBytitle(btitle);
//                int a=db.book().findBytitle(btitle).getResNum();
//                selectedBook = db.book().findByTitle("Strengthening Deep Neural Networks");


//                if (csBook != null) {
//                    Log.d("trial", csBook.toString());
//                } else {
//                    Log.d("trial", "selected book is null");
//                }

                String usn=un.getText().toString();
                String pw=p.getText().toString();
                user = db.user().findByusername(usn);

                for (Book book1 : compSciList) {
                    Log.d("trial", book1.toString());
                }


             //   Book temp = db.book().findByTitle(btitle);

//                if (temp != null) {
//                    Log.d("trial", temp.toString());
//                }


//                Book book2=bookBank.get(0);
//                if (book2 != null) {
//                    Log.d("bookfound",book2.toString());
//                }



                if(btitle.isEmpty() && usn.isEmpty() && pw.isEmpty()){
                    Toast.makeText(CompSci.this, "Please enter all values", Toast.LENGTH_SHORT).show();
                    Log.d("trial",btitle);
                }
                else if(selectedBook != null){
                    String text1="Hold placed on \n Book: "+btitle+"by \n Customer Username"+ usn;
                    Toast.makeText(CompSci.this,text1,Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(CompSci.this, MainActivity.class);
                    db.book().delete(selectedBook);
                    db.transaction().addTransaction(new Transaction("Hold placed on",usn,btitle));

//                    db.book();

                }
                else if(selectedBook== null){
                    String text="Book not found";
                    Toast.makeText(CompSci.this,text,Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}