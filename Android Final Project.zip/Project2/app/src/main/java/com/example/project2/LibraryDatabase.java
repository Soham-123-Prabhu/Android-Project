package com.example.project2;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {User.class,Book.class,Transaction.class},version=9,exportSchema = false)
public abstract class LibraryDatabase extends RoomDatabase {
    private static LibraryDatabase sInstance;
    public abstract UserDAO user();
    public abstract BookDAO book();
    public abstract TransactionDAO transaction();

    public static synchronized LibraryDatabase getInstance(Context context){
        if (sInstance == null) {
            sInstance = Room.databaseBuilder(context.getApplicationContext(),
                            LibraryDatabase.class, "library.db")
                    .fallbackToDestructiveMigration()
                    .allowMainThreadQueries()
                    .build();
        }
        return sInstance;
    }

    public void populateInitialData(){
        runInTransaction(()->{
            if(user().count()==0){
                User u1=new User("anton","t3nn1sch@mp22");
                user().addUser(u1);
                User u2=new User("bernie","thyr01dExp3rt");
                user().addUser(u2);
                User u3=new User("shirleybee","carmel2chicago");
                user().addUser(u3);
            }

            if (book().bcount() == 0) {
                Book b1=new Book("Angela’s Ashes","Frank McCourt","Memoir",100);
                book().AddBook(b1);
                Book b2=new Book("Strengthening Deep Neural Networks","Katy Warr","Computer Science",200);
                book().AddBook(b2);
                Book b3=new Book("Frankenstein","Mary Shelley","Fiction",300);
                book().AddBook(b3);
            }


        });
    }


}