package com.example.project2;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface UserDAO {

    @Insert
    void addUser(User u);

    @Query("SELECT COUNT(*) FROM userBank")
    int count();

    @Query("SELECT * FROM userBank")
    List<User> getAll();

    @Query("SELECT * FROM userBank where (username= :username)")
    User findByusername(String username);

    @Update
    void update(User u);

    @Query("SELECT * FROM userBank where id= :id")
    User findById(int id);

}
